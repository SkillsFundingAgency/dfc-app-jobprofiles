﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using Newtonsoft.Json;
//using System;
//using System.ComponentModel.DataAnnotations;

//namespace DFC.App.JobProfile.Data
//{
//    public class BaseJobProfile
//    {
//        [Required]
//        public Guid JobProfileId { get; set; }

//        [Required]
//        public string CanonicalName { get; set; } = string.Empty;

//        [Required]
//        public long SequenceNumber { get; set; }
//    }
//}