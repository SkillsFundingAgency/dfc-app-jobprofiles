﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//namespace DFC.App.JobProfile.Data.Enums
//{
//    [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.NamingRules", "SA1300:Element should begin with upper-case letter", Justification = "temporary fix")]
//    public enum ContentRelationship
//    {
//        hasWitRestriction,
//        hasWitOtherRequirement,
//        hasWorkingLocation,
//        hasHtbDirectRoute,
//        hasWorkingEnvironment,
//        hasHtbOtherRoute,
//        hasDayToDayTask,
//        hasHtbApprenticeshipRoute,
//        hasONetOccupationalCode,
//        relatedOccupation,
//        hasHtbWorkRoute,
//        hasSocCode,
//        hasWorkingUniform,
//        hasApprenticeshipLink,
//        hasApprenticeshipRequirement,
//        hasHtbCollegeRoute,
//        hasHtbUniversityRoute,
//        hasHtbVolunteeringRoute,
//        requiresHtbRegistration,
//        hasCollegeRequirement,
//        hasCollegeLink,
//        hasRequirementsPrefix,
//        hasUniversityLink,
//        hasUniversityRequirement,
//        hasApprenticeshipStandard,
//    }
//}
