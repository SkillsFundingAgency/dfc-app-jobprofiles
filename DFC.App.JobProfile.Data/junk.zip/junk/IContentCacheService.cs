﻿// TODO: remove(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1512 // Single-line comments should not be followed by blank line
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using System;
//using System.Collections.Generic;

//namespace DFC.App.JobProfile.Data.Contracts
//{
//    public interface IContentCacheService
//    {
//        bool CheckIsContentItem(Guid contentItemId);
//        void Clear();
//        IList<Guid> GetContentIdsContainingContentItemId(Guid contentItemId);
//        void Remove(Guid contentId);
//        void RemoveContentItem(Guid contentId, Guid contentItemId);
//        void AddOrReplace(Guid contentId, List<Guid> contentItemIds);
//    }
//}
