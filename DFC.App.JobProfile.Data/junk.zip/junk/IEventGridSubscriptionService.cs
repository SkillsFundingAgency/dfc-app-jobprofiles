﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using System.Net;
//using System.Threading.Tasks;

//namespace DFC.App.JobProfile.Data.Contracts
//{
//    public interface IEventGridSubscriptionService
//    {
//        Task<HttpStatusCode> CreateAsync();

//        Task<HttpStatusCode> DeleteAsync();
//    }
//}
