﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using DFC.Content.Pkg.Netcore.Data.Models;

//namespace DFC.App.JobProfile.Data.Contracts
//{
//    public interface IPagesApiDataModel
//    {
//        ContentLinksModel ContentLinks { get; set; }

//        // TODO: remove me?
//        /* IList<ApiContentItemModel> ContentItems [ get set ]*/
//    }
//}
