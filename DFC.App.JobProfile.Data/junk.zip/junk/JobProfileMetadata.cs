﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using System.Collections.Generic;

//namespace DFC.App.JobProfile.Data.Models
//{
//    public class JobProfileMetadata : BaseJobProfile
//    {
//        public MetaTags MetaTags { get; set; }

//        public string BreadcrumbTitle { get; set; }

//        public IList<string> AlternativeNames { get; set; }

//        public bool IncludeInSitemap { get; set; }
//    }
//}
