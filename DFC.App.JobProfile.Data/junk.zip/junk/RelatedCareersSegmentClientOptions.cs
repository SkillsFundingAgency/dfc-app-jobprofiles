﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//namespace DFC.App.JobProfile.Data.HttpClientPolicies
//{
//    public class RelatedCareersSegmentClientOptions : SegmentClientOptions
//    {
//    }
//}
