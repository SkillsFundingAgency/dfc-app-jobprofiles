﻿// TODO: fix(?) me!
#pragma warning disable S125 // Sections of code should not be commented out
#pragma warning disable SA1515 // Single-line comment should be preceded by blank line
//using System;

//namespace DFC.App.JobProfile.Data.Models
//{
//    public class SharedContentItemModel
//    {
//        public Guid ItemId { get; set; }

//        public Uri Url { get; set; }

//        public Guid Version { get; set; }

//        public string Content { get; set; }

//        public DateTime CreatedDate { get; set; }

//        public DateTime LastReviewed { get; set; }
//    }
//}
